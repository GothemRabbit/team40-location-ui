import { Component, input } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import SharedModule from 'app/shared/shared.module';
import { DurationPipe, FormatMediumDatePipe, FormatMediumDatetimePipe } from 'app/shared/date';
import { IProductStatus } from '../product-status.model';

@Component({
  standalone: true,
  selector: 'jhi-product-status-detail',
  templateUrl: './product-status-detail.component.html',
  imports: [SharedModule, RouterModule, CommonModule, FormsModule, DurationPipe, FormatMediumDatetimePipe, FormatMediumDatePipe],
})
export class ProductStatusDetailComponent {
  productStatus = input<IProductStatus | null>(null);
  showModal = false;
  rating: number | null = null;
  comment = '';
  previousState(): void {
    window.history.back();
  }
  openReviewModal(): void {
    this.showModal = true;
  }
  closeReviewModal(event?: MouseEvent): void {
    if (!event || (event.target as HTMLElement).classList.contains('modal')) {
      this.showModal = false;
      this.rating = null;
      this.comment = '';
    }
  }
  stopPropagation(event: MouseEvent): void {
    event.stopPropagation();
  }
  submitReview(): void {
    this.closeReviewModal();
  }
}
